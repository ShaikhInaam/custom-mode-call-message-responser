package com.example.interntask8;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.os.Bundle;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.text.InputType;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	Spinner templates;
	TextView message;
	CheckBox busy,active;
	
	public void fileWork()
	{
		try{
			File f=new File("/sdcard/InternTask8/");
			if(f.exists()==false)
			{
				f.mkdir();
			}
			
			File f1=new File("/sdcard/InternTask8/codition.abc/");
			File f2=new File("/sdcard/InternTask8/message.abc/");
			if(f1.exists()==false && f2.exists()==false)
			{
				f1.createNewFile();
				f2.createNewFile();
			}
			if(f1.exists()==true && f2.exists()==true)
			{
				f1.delete();
				f2.delete();
				f1.createNewFile();
				f2.createNewFile();
			}
			
			FileWriter fw=new FileWriter(f1);
			BufferedWriter bw=new BufferedWriter(fw);
			bw.write("bussy");
			bw.close();
			
			FileWriter fw1=new FileWriter(f2);
			BufferedWriter bw1=new BufferedWriter(fw1);
			bw1.write(message.getText().toString());
			bw1.close();
			
			
		}catch(Exception ec)
		{}
	}
	
	
	public void setTemplates()
	{
		ArrayList list=new ArrayList();
		
		list.add("Choose Other Templates");
		list.add("I am bussy dear!");
		list.add("I am bussy!");
		list.add("Can't talk right now!");
		list.add("Whats upp!");
		list.add("i am away!");
		list.add("Contact me later!");
		list.add("Contacting you later!");
		list.add("Wait for a while!");
		
		ArrayAdapter ad=new ArrayAdapter(getApplicationContext(),R.layout.custom,R.id.text,list);
		templates.setAdapter(ad);
		templates.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				String a=templates.getSelectedItem().toString();
				if(!a.equals("Choose Other Templates"))
				{
					message.setText(a);
				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO Auto-generated method stub
				
			}
		});
	}

//-------------------------------------------------------------------------------	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		
		
		busy=(CheckBox)findViewById(R.id.checkBox1);
		active=(CheckBox)findViewById(R.id.checkBox2);
		
		templates=(Spinner)findViewById(R.id.temp);
		message=(TextView)findViewById(R.id.message);
		setTemplates();
		
		
		SharedPreferences shared = getSharedPreferences("mode", MODE_PRIVATE);
		String channel = (shared.getString("mymode", ""));
		//Toast.makeText(getApplicationContext(), channel, 5000).show();
		
		//if(channel.equals("bussy"))
	//	{
	//		busy.setChecked(true);
	//	}
		
	//	if(channel.equals("active"))
	//	{
	//		active.setChecked(true);
	//	}
		
		
	}

	public void active(View v)
	{
		if(busy.isChecked() && active.isChecked())
		{
			Toast.makeText(getApplicationContext(), "you can not tick both at same time", 5000).show();
		}
		
		else if(busy.isChecked() && !active.isChecked())
		{
		
			fileWork();
			
			SharedPreferences shared = getSharedPreferences("mode", MODE_PRIVATE);
			SharedPreferences.Editor editor = shared.edit();
			editor.putString("mymode", "bussy");
			editor.commit();
			
			Toast.makeText(getApplicationContext(), "busy mode activated sucessfully", 5000).show();
			
			AudioManager am;
			am= (AudioManager) getBaseContext().getSystemService(Context.AUDIO_SERVICE);
			am.setRingerMode(AudioManager.RINGER_MODE_SILENT);
			
			Intent i=new Intent(getApplicationContext(),Call.class);
			stopService(i);
			startService(i);
			Intent ii=new Intent(getApplicationContext(),MessageService.class);
			stopService(ii);
			startService(ii);
		}
		
		else if(!busy.isChecked() && active.isChecked())
		{
			SharedPreferences shared = getSharedPreferences("mode", MODE_PRIVATE);
			SharedPreferences.Editor editor = shared.edit();
			editor.putString("mymode", "active");
			editor.commit();
			
			Toast.makeText(getApplicationContext(), "active mode activated sucessfully", 5000).show();
			
			AudioManager am;
			am= (AudioManager) getBaseContext().getSystemService(Context.AUDIO_SERVICE);

			//For Normal mode
			am.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
			
			
			
			Intent i=new Intent(getApplicationContext(),Call.class);
			stopService(i);
			Intent ii=new Intent(getApplicationContext(),MessageService.class);
			stopService(ii);
		}
	}
	
//-------------------------------------------------------------------------
	
	public void custom(View v)
	{
		
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("Custom Message");
		final EditText input = new EditText(this);
		input.setInputType(InputType.TYPE_CLASS_TEXT);
		builder.setView(input);
		builder.setPositiveButton("apply", new OnClickListener() {	
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				message.setText(input.getText().toString());
			}
		});
		
		builder.show();

	}
}
