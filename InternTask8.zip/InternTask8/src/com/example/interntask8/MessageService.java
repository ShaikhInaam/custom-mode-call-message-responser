package com.example.interntask8;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

import android.app.IntentService;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.IBinder;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.widget.Toast;

public class MessageService extends Service{

	
	String str;
	String sender;
	String condition=null;
	String message=null;
	
	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public void onCreate()
	{
		super.onCreate();

		FileReader fr;
		FileReader fr1;
		try {
			fr = new FileReader("/sdcard/InternTask8/codition.abc/");
			BufferedReader br=new BufferedReader(fr);
			
			String line="";
			while((line=br.readLine()) !=null)
			{
				condition=line;
			}
			
			fr1 = new FileReader("/sdcard/InternTask8/message.abc/");
			BufferedReader br1=new BufferedReader(fr1);
			
			String line1="";
			while((line1=br1.readLine()) !=null)
			{
				message=line1;
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		IntentFilter filter = new IntentFilter();
		filter.addAction("android.provider.Telephony.SMS_RECEIVED");

		registerReceiver(rc, filter);
		
		//Toast.makeText(getApplicationContext(), condition, 5000).show();
		//Toast.makeText(getApplicationContext(), message, 5000).show();
		
	}
	
	public void send()
	{
		if(condition.equals("bussy"))
		{
			
		}
	}
	
	
	BroadcastReceiver rc=new BroadcastReceiver()
	{
		@Override
		public void onReceive(Context context, Intent intent) {
			
			if(intent.getAction().equals("android.provider.Telephony.SMS_RECEIVED") && condition.equals("bussy")){
			
				Bundle bundle = intent.getExtras();
		        SmsMessage[] msgs = null;
		        
		        if(bundle!=null){
		         
		        	try{
		            Object[] pdus = (Object[]) bundle.get("pdus");
		            msgs = new SmsMessage[pdus.length];
		 
		            for (int i=0; i < msgs.length; i++) {
		            	
		                msgs[i] = SmsMessage.createFromPdu((byte[]) pdus[i]);
		                str = "SMS from " + msgs[i].getOriginatingAddress()+" : \n";
		                sender=msgs[i].getOriginatingAddress().toString();
		                str += msgs[i].getMessageBody();
		                
		               Toast.makeText(context, str, 2000).show();
		               
		               SmsManager sms=SmsManager.getDefault();
		   			   sms.sendTextMessage(sender, null, message, null, null);
		            }
		
		            }catch(Exception ex)
		            {}
	}
			}
		}

	};
	
	
	

	
		}


	

