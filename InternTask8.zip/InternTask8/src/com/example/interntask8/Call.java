package com.example.interntask8;

import java.io.BufferedReader;
import java.io.FileReader;
import java.lang.reflect.Method;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.telephony.gsm.SmsManager;
import android.widget.Toast;

public class Call extends Service{

	String number;
	String condition=null;
	String message=null;
	
	@Override
	public void onCreate()
	{
		super.onCreate();
		
		FileReader fr;
		FileReader fr1;
		try {
			fr = new FileReader("/sdcard/InternTask8/codition.abc/");
			BufferedReader br=new BufferedReader(fr);
			
			String line="";
			while((line=br.readLine()) !=null)
			{
				condition=line;
			}
			br.close();
		//	Toast.makeText(getApplicationContext(), condition, 5000).show();
			
			fr1 = new FileReader("/sdcard/InternTask8/message.abc/");
			BufferedReader br1=new BufferedReader(fr1);
			
			String line1="";
			while((line1=br1.readLine()) !=null)
			{
				message=line1;
			}
			br1.close();
		//	Toast.makeText(getApplicationContext(), message, 5000).show();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		incommingCall();
		
		
	}
	
	
	
	public void incommingCall()
	{
		TelephonyManager telephonyManager = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);     
        // register PhoneStateListener 
        PhoneStateListener callStateListener = new PhoneStateListener() {
             public void onCallStateChanged(int state, String incomingNumber) 
             {
                     //  React to incoming call.
                     number=incomingNumber;
     
                     // If phone ringing
                     if(state==TelephonyManager.CALL_STATE_RINGING && condition.equals("bussy"))
                     {
                         cutCall(getApplicationContext()); 
                         Toast.makeText(getApplicationContext(),"Phone Is Riging\n"+number, Toast.LENGTH_LONG).show();
                         SmsManager sms=SmsManager.getDefault();
                         sms.sendTextMessage(number, null, message, null, null);
                     }
                     
                     
                     
                     
             }
        };       
        telephonyManager.listen(callStateListener, PhoneStateListener.LISTEN_CALL_STATE);
	
	}
	
	
	
	
	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}

	public void cutCall(Context context)
	{
		  try {

		        String serviceManagerName = "android.os.ServiceManager";
		        String serviceManagerNativeName = "android.os.ServiceManagerNative";
		        String telephonyName = "com.android.internal.telephony.ITelephony";
		        Class<?> telephonyClass;
		        Class<?> telephonyStubClass;
		        Class<?> serviceManagerClass;
		        Class<?> serviceManagerNativeClass;
		        Method telephonyEndCall;
		        Object telephonyObject;
		        Object serviceManagerObject;
		        telephonyClass = Class.forName(telephonyName);
		        telephonyStubClass = telephonyClass.getClasses()[0];
		        serviceManagerClass = Class.forName(serviceManagerName);
		        serviceManagerNativeClass = Class.forName(serviceManagerNativeName);
		        Method getService = // getDefaults[29];
		        serviceManagerClass.getMethod("getService", String.class);
		        Method tempInterfaceMethod = serviceManagerNativeClass.getMethod("asInterface", IBinder.class);
		        Binder tmpBinder = new Binder();
		        tmpBinder.attachInterface(null, "fake");
		        serviceManagerObject = tempInterfaceMethod.invoke(null, tmpBinder);
		        IBinder retbinder = (IBinder) getService.invoke(serviceManagerObject, "phone");
		        Method serviceMethod = telephonyStubClass.getMethod("asInterface", IBinder.class);
		        telephonyObject = serviceMethod.invoke(null, retbinder);
		        telephonyEndCall = telephonyClass.getMethod("endCall");
		        telephonyEndCall.invoke(telephonyObject);

		    } catch (Exception e) {
		        e.printStackTrace();
		    //    Log.d("unable", "msg cant dissconect call....");

		    }
	}
	
	
}
